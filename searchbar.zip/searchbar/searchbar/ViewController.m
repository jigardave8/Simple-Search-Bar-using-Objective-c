//
//  ViewController.m
//  searchbar
//
//  Created by MAC OS on 5/27/16.
//  Copyright © 2016 MAC OS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSArray *searchitem;
    int a;
    
}
@end

@implementation ViewController




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    a=0;
  
    UISearchBar *s1=
    [[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, 100, 40)];
    
    UIBarButtonItem *searchbaritem=
    [[UIBarButtonItem alloc]initWithCustomView:s1];
    
    self.navigationItem.rightBarButtonItem=searchbaritem;
    
    s1.delegate=self;
    
    arr=[[NSMutableArray alloc]initWithObjects:@"jigar",@"kalpesh",@"navin",@"chetan", nil];
    
    searchitem=[[NSArray alloc]init];
    
    _tbl.hidden=NO;
    
    
    
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    if (a==1)
    {
        return searchitem.count;
        
    }
    else
    {
        return arr.count;
    }

}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
UITableViewCell *cell =
[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    if (a==1) {
        cell.textLabel.text=
        [searchitem objectAtIndex:indexPath.row];
        }
    else
    {
        cell.textLabel.text=
        [arr objectAtIndex:indexPath.row];
    }
    return cell;
    

}


-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText

{
   // searchText = nil;
    

    NSPredicate *resultpredicate=[NSPredicate predicateWithFormat:@"SELF contains [cd] %@",searchText];

    searchitem =
    [arr filteredArrayUsingPredicate:resultpredicate];
    
    NSSortDescriptor *sort=
    [[NSSortDescriptor alloc]initWithKey:nil ascending:YES];
    
    searchitem =
    [searchitem sortedArrayUsingDescriptors:[NSArray arrayWithObject:sort]];
    if (!searchitem.count==0) {
        a=1;
    }
    [_tbl reloadData];
    
    
    
    
     
     
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
